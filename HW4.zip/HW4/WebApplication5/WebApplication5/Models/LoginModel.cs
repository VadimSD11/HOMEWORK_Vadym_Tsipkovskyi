﻿namespace WebApplication5.Models
{
    public class LoginModel
    {
    }
}
